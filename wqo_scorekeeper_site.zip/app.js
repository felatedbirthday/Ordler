// Simple W/Q/O Scorekeeper
const STORAGE_KEY = "wqo-scorekeeper-v1";

// Defaults
let state = {
  players: [
    { id: "max", name: "Max" },
    { id: "dad", name: "Dad" },
    { id: "jordan", name: "Jordan" },
  ],
  games: [
    { key: "wordle", label: "Wordle", lowerIsBetter: true },
    { key: "quordle", label: "Quordle", lowerIsBetter: false },
    { key: "octordle", label: "Octordle", lowerIsBetter: false },
  ],
  entries: [] // {id,date,game,scores:{playerId:number},notes}
};

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) state = { ...state, ...JSON.parse(raw) };
  } catch {}
}
function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch {}
}
function uid(){ return Math.random().toString(36).slice(2); }

function $(sel){ return document.querySelector(sel); }
function el(tag, attrs={}, children=[]){
  const e = document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if (k === "class") e.className = v;
    else if (k === "text") e.textContent = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2).toLowerCase(), v);
    else e.setAttribute(k, v);
  });
  (Array.isArray(children)? children:[children]).forEach(c=>{
    if (typeof c === "string") e.appendChild(document.createTextNode(c));
    else if (c) e.appendChild(c);
  });
  return e;
}

function initForm(){
  const today = new Date().toISOString().slice(0,10);
  $("#date").value = today;

  const gameSel = $("#game");
  gameSel.innerHTML = "";
  state.games.forEach(g=>{
    gameSel.appendChild(el("option", { value: g.key, text: g.label }));
  });

  renderPlayerInputs();
  $("#addBtn").addEventListener("click", onAdd);
  $("#resetFormBtn").addEventListener("click", resetForm);
}

function renderPlayerInputs(){
  const wrap = $("#playerInputs");
  wrap.innerHTML = "";
  state.players.forEach(p=>{
    const field = el("div", { class:"field" }, [
      el("label", { text: `${p.name}'s score` }),
      el("input", { type:"number", id:`score-${p.id}`, placeholder:"e.g., 3" })
    ]);
    wrap.appendChild(field);
  });
}

function onAdd(){
  const date = $("#date").value || new Date().toISOString().slice(0,10);
  const game = $("#game").value;
  const notes = $("#notes").value.trim();

  const scores = {};
  let any = false;
  state.players.forEach(p=>{
    const v = $("#score-" + p.id).value;
    if (v !== "" && !isNaN(Number(v))) { scores[p.id] = Number(v); any = true; }
  });
  if (!any) return alert("Enter at least one score.");

  state.entries.unshift({ id: uid(), date, game, scores, notes });
  save();
  resetForm();
  renderHistory();
  renderLeaderboards();
}

function resetForm(){
  $("#notes").value = "";
  state.players.forEach(p=>{ const f = $("#score-"+p.id); if (f) f.value=""; });
  $("#game").selectedIndex = 0;
  $("#date").value = new Date().toISOString().slice(0,10);
}

function renderHistory(){
  const body = $("#historyBody");
  body.innerHTML = "";
  const gameMap = Object.fromEntries(state.games.map(g=>[g.key,g]));
  state.entries.forEach(e=>{
    const row = el("tr", {}, [
      el("td", { text: e.date }),
      el("td", { text: gameMap[e.game]?.label || e.game }),
      ...state.players.map(p=> el("td", { text: (e.scores[p.id] ?? "—").toString() })),
      el("td", { text: e.notes || "" }),
      el("td", {}, el("button", { class:"btn danger", onClick:()=>{ deleteEntry(e.id); }, text:"🗑" }))
    ]);
    body.appendChild(row);
  });
}
function deleteEntry(id){
  state.entries = state.entries.filter(x=>x.id !== id);
  save(); renderHistory(); renderLeaderboards();
}

function renderLeaderboards(){
  // Overall averages
  const totals = Object.fromEntries(state.players.map(p=>[p.id,{sum:0,count:0}]));
  state.entries.forEach(e=>{
    state.players.forEach(p=>{
      const v = e.scores[p.id];
      if (typeof v === "number"){ totals[p.id].sum += v; totals[p.id].count += 1; }
    });
  });

  const overall = $("#leaderboardOverall");
  overall.innerHTML = "";
  state.players.forEach(p=>{
    const {sum, count} = totals[p.id];
    const avg = count ? (sum/count).toFixed(2) : "—";
    overall.appendChild(el("div", { class:"leader-card" }, [
      el("div", { class:"name", text: p.name }),
      el("div", { class:"score", text: avg }),
      el("div", { class:"hint", text: "Overall average" })
    ]));
  });

  // Per-game averages
  const per = {};
  state.games.forEach(g=>{
    per[g.key] = Object.fromEntries(state.players.map(p=>[p.id,{sum:0,count:0}]));
  });
  state.entries.forEach(e=>{
    state.players.forEach(p=>{
      const v = e.scores[p.id];
      if (typeof v === "number"){
        per[e.game][p.id].sum += v;
        per[e.game][p.id].count += 1;
      }
    });
  });

  const perWrap = $("#leaderboardPerGame");
  perWrap.innerHTML = "";
  state.games.forEach(g=>{
    const gameDiv = el("div", { class:"game" }, [
      el("h4", { text: g.label + (g.lowerIsBetter? " (lower is better)":" (higher is better)") })
    ]);
    const row = el("div", { class:"leaderboard" });
    state.players.forEach(p=>{
      const {sum, count} = per[g.key][p.id];
      const avg = count ? (sum/count).toFixed(2) : "—";
      row.appendChild(el("div", { class:"leader-card" }, [
        el("div", { class:"name", text: p.name }),
        el("div", { class:"score", text: avg }),
        el("div", { class:"hint", text: `${count} game${count===1?"":"s"}` })
      ]));
    });
    gameDiv.appendChild(row);
    perWrap.appendChild(gameDiv);
  });
}

// Settings
function renderPlayers(){
  const chips = $("#playerChips");
  chips.innerHTML = "";
  state.players.forEach(p=>{
    const chip = el("span", { class:"chip" }, [
      p.name,
      el("button", { onClick:()=>{ removePlayer(p.id); }, text: "×" })
    ]);
    chips.appendChild(chip);
  });
}
function removePlayer(id){
  state.players = state.players.filter(p=>p.id!==id);
  save(); renderPlayers(); renderPlayerInputs(); renderHistory(); renderLeaderboards();
}
function addPlayer(){
  const inp = $("#newPlayer");
  const name = inp.value.trim();
  if(!name) return;
  const id = name.toLowerCase().replace(/[^a-z0-9]+/g,"-") + "-" + uid().slice(0,4);
  state.players.push({ id, name });
  inp.value = "";
  save(); renderPlayers(); renderPlayerInputs(); renderHistory(); renderLeaderboards();
}

function renderGames(){
  const wrap = $("#gamesList");
  wrap.innerHTML = "";
  state.games.forEach(g=>{
    const row = el("div", { class:"row wrap" }, [
      el("div", { class:"chip", text: `${g.label}` }),
      el("button", { class:"btn", onClick:()=>toggleRule(g.key), text: `Toggle rule (${g.lowerIsBetter? "Lower":"Higher"} better)` })
    ]);
    wrap.appendChild(row);
  });
}
function toggleRule(key){
  state.games = state.games.map(g=> g.key===key ? { ...g, lowerIsBetter: !g.lowerIsBetter } : g);
  save(); renderGames();
}

// Data IO
function exportJSON(){
  const blob = new Blob([JSON.stringify(state, null, 2)], {type:"application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "wqo-score-export.json"; a.click();
  URL.revokeObjectURL(url);
}
function importJSON(e){
  const file = e.target.files?.[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const data = JSON.parse(reader.result);
      if (data.players) state.players = data.players;
      if (data.games) state.games = data.games;
      if (data.entries) state.entries = data.entries;
      save();
      initForm(); renderPlayers(); renderGames(); renderHistory(); renderLeaderboards();
    } catch { alert("Invalid JSON"); }
  };
  reader.readAsText(file);
}
function resetAll(){
  if (!confirm("Clear all data? This cannot be undone.")) return;
  localStorage.removeItem(STORAGE_KEY);
  state.entries = [];
  initForm(); renderPlayers(); renderGames(); renderHistory(); renderLeaderboards();
}

// Wire up
load();
window.addEventListener("DOMContentLoaded", ()=>{
  initForm();
  renderPlayers();
  renderGames();
  renderHistory();
  renderLeaderboards();

  $("#addPlayerBtn").addEventListener("click", addPlayer);
  $("#exportBtn").addEventListener("click", exportJSON);
  $("#importInput").addEventListener("change", importJSON);
  $("#resetAllBtn").addEventListener("click", resetAll);
});
